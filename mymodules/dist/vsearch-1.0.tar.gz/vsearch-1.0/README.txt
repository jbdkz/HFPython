The Head First Python Search Tools
